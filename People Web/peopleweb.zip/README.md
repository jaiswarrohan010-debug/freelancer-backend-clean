# People - Business Website

A professional website for People, a platform that connects clients with skilled freelancers for various professional services.

## 🌟 Features

### Home Page (`index.html`)
- **Modern Design**: Clean, professional layout with white background and blue/green color scheme
- **Responsive Navigation**: Mobile-friendly navigation with hamburger menu
- **Hero Section**: Compelling introduction with call-to-action buttons
- **How It Works**: Clear explanation of the platform for both clients and freelancers
- **Features Section**: Highlighting key benefits and platform advantages
- **About Section**: Company information and statistics
- **Call-to-Action**: Encouraging user engagement

### Terms and Conditions (`terms.html`)
- **Comprehensive Legal Coverage**: Detailed terms covering all aspects of platform usage
- **User Responsibility**: Clear disclaimers about user accountability for activities
- **Illegal Activities Disclaimer**: Explicit statement that users are responsible for their actions
- **Liability Limitations**: Protection clauses for the company
- **Verification Requirements**: Details about freelancer verification processes
- **Payment Terms**: Financial and transaction-related terms



## 🎨 Design Features

### Color Scheme
- **Primary Blue**: `#2563eb` - Used for client-related elements and primary actions
- **Primary Green**: `#059669` - Used for freelancer-related elements and secondary actions
- **White Background**: Clean, professional appearance
- **Gray Scale**: Various shades for text and subtle elements

### Typography
- **Font Family**: Inter (Google Fonts) - Modern, readable, professional
- **Font Weights**: 300, 400, 500, 600, 700 for hierarchy

### Responsive Design
- **Mobile-First**: Optimized for all device sizes
- **Flexible Grid**: CSS Grid and Flexbox for layout
- **Touch-Friendly**: Appropriate button sizes and spacing

## 📱 Interactive Features

### JavaScript Functionality
- **Mobile Navigation**: Hamburger menu for mobile devices
- **Smooth Scrolling**: Animated navigation between sections
- **Scroll Effects**: Navbar background changes on scroll
- **Animation**: Elements animate on scroll for better UX
- **Form Validation**: Ready for future form implementations

### User Experience
- **Loading Animations**: Smooth page transitions
- **Hover Effects**: Interactive elements with visual feedback
- **Accessibility**: Proper semantic HTML and ARIA labels

## 📁 File Structure

```
People Web/
├── index.html          # Home page
├── terms.html          # Terms and Conditions
├── styles.css          # Main stylesheet
├── script.js           # JavaScript functionality
├── 1000013213 (1).png  # Company logo
└── README.md           # This file
```

## 🚀 Getting Started

1. **Open the Website**: Simply open `index.html` in any modern web browser
2. **Navigate**: Use the navigation menu to explore different sections
3. **Mobile Testing**: Test on mobile devices or use browser developer tools
4. **Customization**: Modify colors, content, or styling in the respective files

## 🛠️ Customization

### Colors
Edit the CSS variables in `styles.css`:
```css
:root {
    --primary-blue: #2563eb;
    --primary-green: #059669;
    /* ... other colors */
}
```

### Content
- **Home Page**: Edit content in `index.html`
- **Terms**: Modify legal text in `terms.html`
- **Privacy**: Update privacy information in `privacy.html`

### Styling
- **Layout**: Modify CSS Grid and Flexbox properties
- **Typography**: Change font sizes and weights
- **Animations**: Adjust transition timings and effects

## 📧 Contact Information

The website includes contact information:
- **Email**: rohanjaiswar2467@gmail.com
- **Phone**: +91 7021098460
- **Address**: Mumbai, Maharashtra, India

## 🔒 Legal Compliance

### Terms and Conditions
- Comprehensive coverage of platform usage
- User responsibility disclaimers
- Liability limitations
- Verification requirements
- Payment and financial terms

### Privacy Policy
- GDPR-compliant data handling
- Aadhar card verification requirements
- User consent management
- Data security measures
- User rights and choices

## 🌐 Browser Compatibility

- **Chrome**: Full support
- **Firefox**: Full support
- **Safari**: Full support
- **Edge**: Full support
- **Mobile Browsers**: Optimized for iOS Safari and Chrome Mobile

## 📱 Mobile Optimization

- **Responsive Design**: Adapts to all screen sizes
- **Touch-Friendly**: Appropriate button sizes and spacing
- **Fast Loading**: Optimized images and code
- **Mobile Navigation**: Hamburger menu for small screens

## 🎯 Key Features for Your Business

### For Clients
- Easy job posting and freelancer discovery
- Secure payment processing
- Quality assurance and dispute resolution
- Professional service providers

### For Freelancers
- Profile creation and verification
- Project discovery and bidding
- Secure payment receipt
- Professional growth opportunities

### Platform Benefits
- Verified professionals with government document checks
- Secure escrow payment system
- 24/7 customer support
- Comprehensive dispute resolution

## 🔧 Technical Details

### Technologies Used
- **HTML5**: Semantic markup
- **CSS3**: Modern styling with Grid and Flexbox
- **JavaScript**: Interactive functionality
- **Font Awesome**: Icons
- **Google Fonts**: Typography

### Performance
- **Optimized Images**: Web-optimized graphics
- **Minimal Dependencies**: Only essential external resources
- **Fast Loading**: Efficient code structure
- **SEO Ready**: Proper meta tags and structure

## 📈 Future Enhancements

Potential additions for future development:
- **Contact Forms**: Lead generation forms
- **Blog Section**: Content marketing
- **Testimonials**: User reviews and feedback
- **Service Categories**: Detailed service listings
- **Pricing Plans**: Subscription or fee structures
- **Live Chat**: Customer support integration

## 📞 Support

For technical support or customization requests:
- **Email**: rohanjaiswar2467@gmail.com
- **Phone**: +91 7021098460

---

**Note**: This website is designed to be professional, legally compliant, and user-friendly. The Terms and Conditions are comprehensive and address the specific requirements of your platform, including the collection of government documents and user responsibility disclaimers.
